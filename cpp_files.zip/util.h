#pragma once
#define _CRT_SECURE_NO_WARNINGS

#define _PI		(3.1415926535897932384626433832795028841971)

void gotoxy(int x, int y);
void textcolor(int foreground, int background);

double RAD(const double& x);
double DEG(const double& x);
